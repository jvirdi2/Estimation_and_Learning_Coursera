% Robotics: Estimation and Learning 
% WEEK 3
% 
% Complete this function following the instruction. 
function myMap = occGridMapping(ranges, scanAngles, pose, param)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Parameters 
% 
% % the number of grids for 1 meter.
myResol = param.resol;
% % the initial map size in pixels
myMap = zeros(param.size);
% % the origin of the map in pixels
myorigin = param.origin; 


% % 4. Log-odd parameters 
lo_occ = param.lo_occ;
lo_free = param.lo_free; 
lo_max = param.lo_max;
lo_min = param.lo_min;
N = size(pose,2);
for j = 1:N % for each time,
% 
%       
%     % Find grids hit by the rays (in the gird map coordinate)
      
      robot_x=pose(1,j);
      robot_y=pose(2,j);
      robot_theta=pose(3,j);
      robot_grid_x = ceil(robot_x*myResol)+ myorigin(1);
      robot_grid_y=ceil(robot_y*myResol)+ myorigin(2);
      theta_plus_alpha=robot_theta+scanAngles; %1081x1
      x_occ_all=ranges(:,j).*cos(theta_plus_alpha);%1081x1
      y_occ_all=(-ranges(:,j).*sin(theta_plus_alpha));%1081x1
      x_occ_real=x_occ_all+robot_x;%1081x1. All occupied position's x coordinates
      y_occ_real=y_occ_all+robot_y;%1081x1. All occupied position's y coordinates
      index_x=ceil(x_occ_real*myResol)+myorigin(1);
      index_y=ceil(y_occ_real*myResol)+myorigin(2);
%     % Find occupied-measurement cells and free-measurement cells
      for p=1:1081
       [freex, freey] = bresenham(robot_grid_x,robot_grid_y,index_x(p),index_y(p));  
%     % Update the log-odds
        length_free=size(freex);
        myMap(index_y(p),index_x(p))=min(myMap(index_y(p),index_x(p))+lo_occ,lo_max);
        if length_free(1)>0 && length_free(2)>0 
            for m=1:length_free(1)
                myMap(freey(m),freex(m))=max(myMap(freey(m),freex(m))-lo_free,lo_min);
            end
        end
      end
end


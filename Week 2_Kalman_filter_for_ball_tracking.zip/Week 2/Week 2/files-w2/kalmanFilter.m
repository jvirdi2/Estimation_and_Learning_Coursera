function [ predictx, predicty, state, param ] = kalmanFilter( t, x, y, state, param, previous_t )
%UNTITLED Summary of this function goes here
%   Four dimensional state: position_x, position_y, velocity_x, velocity_y

    %% Place parameters like covarainces, etc. here:
    % P = eye(4)
    % R = eye(2)

    % Check if the first time running this function
    if previous_t<0
        state = [x, y, 0, 0];
        param.P = 0.1 * eye(4);
        predictx = x;
        predicty = y;
        return;
    end

    %% TODO: Add Kalman filter updates
    % As an example, here is a Naive estimate without a Kalman filter
    % You should replace this code
    dt=t-previous_t;
    A=[1 0 dt 0;0 1 0 dt;0 0 1 0;0 0 0 1];
    C=[1 0 0 0;0 1 0 0];
    noise_sensor=(0.01)*eye(2);
    noise_state= [0.1 0.01 0.01 0.01 ;
                  0.01 0.1  0.01  0.1;
                  0.01 0.01 0.15 0.01;
                   0.01 0.1  0.01 0.15];
    R=C*param.P*C'+noise_sensor;
    P_kalman=A*param.P*A'+noise_state;
    Kalman_gain=(P_kalman)*C'/(R+C*P_kalman*C');
    
    predict = (A*state'+Kalman_gain*([x;y]-C*A*state'))';
    state=predict;
    alpha=P_kalman-Kalman_gain*C*P_kalman;
    param.P=alpha;
    predictx = state(1) + state(3)*(0.330);
    predicty = state(2) + state(4)*(0.330);
end

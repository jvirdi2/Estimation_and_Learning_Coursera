% Robotics: Estimation and Learning 
% WEEK 4
% 
% Complete this function following the instruction. 
function myPose = particleLocalization(ranges, scanAngles, map, param)

% Number of poses to calculate
N = size(ranges, 2);
% Output format is [x1 x2, ...; y1, y2, ...; z1, z2, ...]
myPose = zeros(3, N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Map Parameters 
% 
% % the number of grids for 1 meter.
myResolution = param.resol;
% % the origin of the map in pixels
myOrigin = param.origin; 

% The initial pose is given
myPose(:,1) = param.init_pose;
% You should put the given initial pose into myPose for j=1, ignoring the j=1 ranges. 
% The pose(:,1) should be the pose when ranges(:,j) were measured.



% Decide the number of particles, M.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M =1500;                            % Please decide a reasonable number of M, 
                               % based on your experiment using the practice data.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create M number of particles
P = repmat(myPose(:,1), [1, M]);

for j = 2:N % You will start estimating myPose from j=2 using ranges(:,2).
%    % 1) Propagate the particles 
     %odometry_random=normrnd(0,0.1,[3,1]);
     j
     new_positions=zeros(3,M);
     corelation_score=zeros(M,1);
     new_weight=zeros(M,1);
     initial_weight=1/M;
     noise_u = [0 0 0];
     noise_sigma = diag([0.04 0.04 0.03]);
     for p=1:M
         new_positions(:,p)=myPose(:,j-1)+mvnrnd(noise_u,noise_sigma)';   
%     % 2) Measurement Update 
%     %   2-1) Find grid cells hit by the rays (in the grid map coordinate frame)    
         robot_x=new_positions(1,p);
         robot_y=new_positions(2,p);
         robot_theta=new_positions(3,p);
         robot_grid_x = ceil(robot_x*myResolution)+ myOrigin(1);
         robot_grid_y=ceil(robot_y*myResolution)+ myOrigin(2);
         theta_plus_alpha=robot_theta+scanAngles; %1081x1
         x_occ_all=ranges(:,j).*cos(theta_plus_alpha);%1081x1
         y_occ_all=(-ranges(:,j).*sin(theta_plus_alpha));%1081x1
         x_occ_real=x_occ_all+robot_x;%1081x1. All occupied position's x coordinates
         y_occ_real=y_occ_all+robot_y;%1081x1. All occupied position's y coordinates
         index_x=ceil(x_occ_real*myResolution)+myOrigin(1);
         index_y=ceil(y_occ_real*myResolution)+myOrigin(2);
         for k=1:1081
             %[freex, freey] = bresenham(robot_grid_x,robot_grid_y,index_x(k),index_y(k)); 
             %length_free=size(freex);
%     %   2-2) For each particle, calculate the correlation scores of the particles
                 if robot_grid_x>=1 && robot_grid_x<=size(map,2) && robot_grid_y>=1 && robot_grid_y<=size(map,1)
                    if index_x(k)>=1 && index_x(k)<=size(map,2) && index_y(k)>=1 &&  index_y(k)<=size(map,1)  
                        if map(robot_grid_y,robot_grid_x)<0
                            if map(index_y(k),index_x(k))>=0.49  % The index_y(k),index_x(k) gives us LIDAR occupancy
                                corelation_score(p)=corelation_score(p)+10;% Here both occupied case
                            end
                            if map(index_y(k),index_x(k))<0  % map is empty for LIDAR occupied states
                                corelation_score(p)=corelation_score(p)-5;
                            end
                        end
                    end
                 end
         end
         new_weight(p)=initial_weight*corelation_score(p);
     end
     new_weight_sum_one=new_weight/sum(new_weight);  
     [value,index]=max(new_weight_sum_one);
     myPose(:,j)=new_positions(:,index);
end
end

             %if length_free(1)>0 && length_free(2)>0
                 %for q=1:length_free(1)
                     %if map(min(freey(q),size(M,2)),min(freex(q),size(M,1)))>=0.5 % map is occupied for LIDAR empty
                        %corelation_score(p)=corelation_score(p)-5;
                     %end
                     %if map(min(freey(q),size(M,2)),min(freex(q),size(M,1)))<-0.2 % map is empty for LIDAR empty
                        %corelation_score(p)=corelation_score(p)+1;
                     %end
                 %end
             %end
              
         
%     %   2-3) Update the particle weights         
      
%     %   2-4) Choose the best particle to update the pose
      
%     % 3) Resample if the effective number of particles is smaller than a threshold
 %     effective_number_particles=(sum(new_weight_sum_one))^2/(sum(new_weight_sum_one.*new_weight_sum_one));
%     % 4) Visualize the pose on the map as needed
 %     if effective_number_particles<M/2
          
% 
% end


      

                    

        
              
            
                
                
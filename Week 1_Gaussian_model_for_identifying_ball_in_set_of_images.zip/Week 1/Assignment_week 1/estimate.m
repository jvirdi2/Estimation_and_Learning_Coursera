function [sigma_vec,covariance_matrix]=estimate(processed_samples)
% processed samples is mx3 matrix having R,G,B values of target specimen
% Assuming only 1 gaussian
% sigma_vec=3x1matrix
% Covariance matrix=3x3 matrix
N=size(processed_samples);
average_red=sum(processed_samples(:,1));
average_green=sum(processed_samples(:,2));
average_blue=sum(processed_samples(:,3));
sigma_vec=(1/N(1))*[average_red;average_green;average_blue];

vector=processed_samples';
difference=double(vector)-sigma_vec;
covariance_matrix=(1/N(1))*(difference*difference');

end

